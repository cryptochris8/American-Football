// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


export function QBTutorialSystem(world: World, dt: number) {
  // Simple state machine tutorial:
  // 1. Show "Move aim with mouse / WASD".
  // 2. After player moves aim, show "Hold SPACE to charge throw".
  // 3. After first throw, show "Hit targets to build your multiplier".
  // 4. After first hit, hide tutorial prompts.
}
