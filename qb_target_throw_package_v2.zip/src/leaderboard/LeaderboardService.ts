// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


// Leaderboard stub.
// You can point this at a backend API, Supabase, Firebase, or a simple
// local JSON store depending on your Hytopia deployment.

export interface LeaderboardEntry {
  playerName: string;
  score: number;
  accuracyPercent: number;
  createdAt: string;
}

export class LeaderboardService {
  async submitScore(entry: LeaderboardEntry): Promise<void> {
    // TODO: POST to your backend route or store locally.
  }

  async getTopScores(limit: number = 25): Promise<LeaderboardEntry[]> {
    // TODO: GET from your backend route or local store.
    return [];
  }
}
