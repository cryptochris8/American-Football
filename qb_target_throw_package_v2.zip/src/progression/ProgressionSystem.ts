// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


// Very lightweight progression model:
// - Player earns XP based on score and accuracy.
// - Higher levels can unlock cosmetics (ball skins, field themes, target styles).

export function ProgressionSystem(world: World, dt: number) {
  // TODO:
  // - At end of round, convert score -> XP.
  // - Accumulate XP per player account or local profile.
  // - Track level thresholds in a small JSON or inline table.
}
