// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


export function TargetLifetimeSystem(world: World, dt: number) {
  // TODO:
  // - Decrease Lifetime on bonus targets and despawn when <= 0.
}
