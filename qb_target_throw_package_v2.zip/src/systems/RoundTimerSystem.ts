// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


export function RoundTimerSystem(world: World, dt: number) {
  // TODO:
  // - Decrement timeRemainingSeconds on the game_controller.
  // - When it hits 0, mark the round as ended and fire OnQBRoundEnded.
}
