// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


export function RoundStateInitSystem(world: World, dt: number) {
  // TODO:
  // - When player enters this scene, reset the game_controller state and show start panel.
}
