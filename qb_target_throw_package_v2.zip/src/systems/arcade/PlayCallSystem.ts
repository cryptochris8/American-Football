// Auto-generated arcade football system stubs.
// Wire these into your Hytopia ECS and input APIs in Claude Code.

import { World } from "hytopia-ecs-placeholder"; // replace with real import


export function PlayCallSystem(world: World, dt: number) {
  // TODO:
  // - Show a small play selection UI when between plays.
  // - Allow player to choose one offensive play.
  // - Store chosen play on the af_game_controller or offense team entity.
}
