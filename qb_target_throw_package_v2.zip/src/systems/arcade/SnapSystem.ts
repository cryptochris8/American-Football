// Auto-generated arcade football system stubs.
// Wire these into your Hytopia ECS and input APIs in Claude Code.

import { World } from "hytopia-ecs-placeholder"; // replace with real import


export function SnapSystem(world: World, dt: number) {
  // TODO:
  // - On snap, move ball from center to QB or RB.
  // - Mark the play state as 'in_progress'.
  // - Start the game clock if it's not already running.
}
