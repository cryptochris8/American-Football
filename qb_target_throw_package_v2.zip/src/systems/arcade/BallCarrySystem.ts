// Auto-generated arcade football system stubs.
// Wire these into your Hytopia ECS and input APIs in Claude Code.

import { World } from "hytopia-ecs-placeholder"; // replace with real import


export function BallCarrySystem(world: World, dt: number) {
  // TODO:
  // - Let the local player control the current ball carrier with simple
  //   directional input (up/down/left/right relative to field).
}
