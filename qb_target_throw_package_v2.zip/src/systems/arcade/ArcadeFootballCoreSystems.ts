// Auto-generated arcade football system stubs.
// Wire these into your Hytopia ECS and input APIs in Claude Code.

import { World } from "hytopia-ecs-placeholder"; // replace with real import


export function ArcadeFootballCoreSystems(world: World, dt: number) {
  // Optionally a single entry point to call PlayCallSystem, SnapSystem, etc.
}
