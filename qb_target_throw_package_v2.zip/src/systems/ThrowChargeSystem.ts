// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


export function ThrowChargeSystem(world: World, dt: number) {
  // TODO: 
  // - Track when the throw key (Space) is pressed / held / released.
  // - Maintain a charge value on the QB entity (0..1).
  // - Expose current charge to the UI power bar.
}
