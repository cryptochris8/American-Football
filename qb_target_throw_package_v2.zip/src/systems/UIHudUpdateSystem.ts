// Auto-generated starter system for QB Target Throw
// NOTE: Wire this into the actual Hytopia ECS / MCP APIs inside Claude Code.

import { World, Entity } from "hytopia-ecs-placeholder"; // replace with real import


export function UIHudUpdateSystem(world: World, dt: number) {
  // TODO:
  // - Sync game_controller state into UI widgets (score, timer, etc.).
}
